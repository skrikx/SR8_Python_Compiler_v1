# SR8 Compiler v1 Workflow Prompt Package

This archive packages the SRX ACE workflow prompts forged in chat for the SR8 Compiler v1 arc.

## Included

- WF01 through WF08 as individual workflow XML files
- WF09 and WF10 preserved as the original combined one-pass-lock XML response
- WF11 original and WF11 evolved
- WF12
- WF13
- WF14
- WF15
- Unified WF13 + WF14 + WF15 execution pack

## Integrity

- `manifest.json` includes SHA-256 hashes for every packaged file.
- Prompt files are stored as raw XML blocks.
- Combined and evolved variants are preserved when they existed in chat.

## File map

- `workflows/` - individual or combined workflow prompt XML files
- `execution_packs/` - multi-workflow unified execution packs
- `manifest.json` - file manifest with hashes and sizes
- `README.md` - package notes

## Output package

- `SR8_Compiler_v1_Workflows.zip`
